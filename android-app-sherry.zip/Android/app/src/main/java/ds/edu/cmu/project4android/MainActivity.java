/**
 * Author: Sherry Zhang
 * Project 4
 * Disclaimer: this code got help from GenAI for bug fix
 */

package ds.edu.cmu.project4android;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    EditText inputKeyword;
    TextView resultText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputKeyword = findViewById(R.id.inputKeyword);
        resultText = findViewById(R.id.resultText);
        Button btnSearch = findViewById(R.id.btnSearch);

        // allow network on main thread for simplicity (OK for class project)
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String keyword = inputKeyword.getText().toString().trim();

                if (keyword.isEmpty()) {
                    resultText.setText("Please enter a keyword.");
                    return;
                }

                try {
                    String apiUrl = "https://ubiquitous-pancake-v6794gx9r9vrfw7jq-8080.app.github.dev/books?keyword="
                            + keyword;

                    URL url = new URL(apiUrl);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("GET");

                    BufferedReader br = new BufferedReader(
                            new InputStreamReader(conn.getInputStream())
                    );

                    StringBuilder response = new StringBuilder();
                    String line;

                    while ((line = br.readLine()) != null) {
                        response.append(line);
                    }

                    br.close();
                    conn.disconnect();

                    // Try parse JSON
                    JSONArray arr = new JSONArray(response.toString());

                    StringBuilder out = new StringBuilder();

                    for (int i = 0; i < Math.min(5, arr.length()); i++) {
                        JSONObject obj = arr.getJSONObject(i);

                        out.append("Title: ").append(obj.getString("title")).append("\n")
                                .append("Author: ").append(obj.getString("author")).append("\n")
                                .append("Year: ").append(obj.getString("firstPublishYear")).append("\n\n");
                    }

                    resultText.setText(out.toString());

                } catch (Exception e) {
                    resultText.setText("Error:\n" + e.toString());
                }
            }
        });
    }
}
