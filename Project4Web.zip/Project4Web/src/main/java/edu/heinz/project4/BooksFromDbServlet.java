/*
Author: Sherry Zhang
Date: 11/21/2025
Project 4
Disclaimer: I used GenAI tools to help me debug my code.
 */
package edu.heinz.project4;

import com.google.gson.Gson;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.bson.Document;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "BooksFromDbServlet", value = "/books-from-db")
public class BooksFromDbServlet extends HttpServlet {

    private static final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        resp.setContentType("application/json;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        try {
            MongoCollection<Document> col = MongoUtil.getBookCollection();

            // sort by savedAt DESC
            FindIterable<Document> docs = col.find().sort(new Document("savedAt", -1));

            List<Book> result = new ArrayList<>();

            for (Document d : docs) {
                String title = d.getString("title");
                String author = d.getString("author");
                int year = d.getInteger("firstPublishYear", 0);

                result.add(new Book(title, author, year));
            }

            out.println(gson.toJson(result));

        } catch (Exception e) {
            e.printStackTrace();
            resp.setStatus(500);
            out.println("{\"error\":\"db read failed\"}");
        }
    }
}
