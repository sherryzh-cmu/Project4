/*
Author: Sherry Zhang
Date: 11/21/2025
Project 4
Disclaimer: I used GenAI tools to help me debug my code.
 */
package edu.heinz.project4;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.bson.Document;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import java.io.PrintWriter;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.logging.Logger;

@WebServlet(name = "BookServlet", value = "/books")
public class BookServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(BookServlet.class.getName());
    private static final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws IOException, ServletException {

        long reqStartTime = System.currentTimeMillis();
        resp.setContentType("application/json;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        LOGGER.info("Incoming request /books");

        // ===== log fields we will fill later =====
        String keyword = req.getParameter("keyword");
        if (keyword == null || keyword.isEmpty()) keyword = "java";

        int resultCount = 0;
        long apiLatency = 0;
        String serverStatus = "OK";

        try {
            // 1. OpenLibrary API
            String apiURL = "https://openlibrary.org/search.json?q=" + keyword;

            long apiStart = System.currentTimeMillis();

            URL url = new URL(apiURL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(8000);
            conn.setRequestMethod("GET");

            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;

            while ((line = br.readLine()) != null) sb.append(line);

            br.close();
            conn.disconnect();

            apiLatency = System.currentTimeMillis() - apiStart;
            LOGGER.info("API latency = " + apiLatency + " ms");

            // 2. Parse response JSON
            Type type = new TypeToken<BookResponse>() {}.getType();
            BookResponse r = gson.fromJson(sb.toString(), type);

            List<Book> books = r.toSimpleList();
            resultCount = books.size();
            LOGGER.info("resultCount = " + resultCount);

            // 3. Insert books into MongoDB
            try {
                for (Book b : books) {
                    Document doc = new Document()
                            .append("title", b.title)
                            .append("author", b.author)
                            .append("firstPublishYear", b.firstPublishYear)
                            .append("keyword", keyword)
                            .append("savedAt", System.currentTimeMillis());
                    MongoUtil.getBookCollection().insertOne(doc);

                }
            } catch (Exception e) {
                LOGGER.severe("Mongo insert ERROR: " + e.getMessage());
            }

            // 4. Send output
            out.println(gson.toJson(books));
            out.flush();

        } catch (Exception e) {
            serverStatus = "ERROR";
            LOGGER.severe("BOOK API ERROR: " + e.getMessage());
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.println("{\"error\":\"internal server error\"}");
        }

        // ===== 5. Write logs into MongoDB =====
        try {
            long totalTime = System.currentTimeMillis() - reqStartTime;

            Document log = new Document()
                    .append("timestamp", System.currentTimeMillis())
                    .append("keyword", keyword)
                    .append("apiLatency", apiLatency)
                    .append("resultCount", resultCount)
                    .append("clientIP", req.getRemoteAddr())
                    .append("serverStatus", serverStatus)
                    .append("totalTime", totalTime);

            MongoUtil.getLogsCollection().insertOne(log);
            LOGGER.info("Log saved into MongoDB.");
            System.out.println(">>> Writing log to MongoDB...");

        } catch (Exception e) {
            LOGGER.severe("Failed writing logs: " + e.getMessage());
        }
    }
}
