/*
Author: Sherry Zhang
Date: 11/21/2025
Project 4
Disclaimer: I used GenAI tools to help me debug my code.
 */
package edu.heinz.project4;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.heinz.project4.MongoUtil;
import org.bson.Document;

import java.io.IOException;
import java.util.*;

@WebServlet(name = "DashboardServlet", value = "/dashboard")
public class DashboardServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        MongoCollection<Document> logsCol = MongoUtil.getLogsCollection();

        List<Document> allLogs = new ArrayList<>();

        try (MongoCursor<Document> cursor = logsCol.find().iterator()) {
            while (cursor.hasNext()) {
                allLogs.add(cursor.next());
            }
        }

        // 1. total request count
        int totalRequests = allLogs.size();

        // 2. success vs error count
        long successCount = allLogs.stream()
                .filter(l -> "OK".equals(l.getString("serverStatus")))
                .count();

        long errorCount = totalRequests - successCount;

        // 3. Top 5 keywords
        Map<String, Integer> freq = new HashMap<>();
        for (Document log : allLogs) {
            String kw = log.getString("keyword");
            freq.put(kw, freq.getOrDefault(kw, 0) + 1);
        }
        List<Map.Entry<String, Integer>> topKeywords = new ArrayList<>(freq.entrySet());
        topKeywords.sort((a, b) -> b.getValue() - a.getValue());
        if (topKeywords.size() > 5) {
            topKeywords = topKeywords.subList(0, 5);
        }

        // 4. average API latency
        double avgLatency = allLogs.stream()
                .mapToLong(l -> {
                    Number n = (Number) l.get("apiLatency");
                    return n == null ? 0 : n.longValue();
                })
                .average()
                .orElse(0.0);

        // Pass data to JSP
        req.setAttribute("logs", allLogs);
        req.setAttribute("totalRequests", totalRequests);
        req.setAttribute("successCount", successCount);
        req.setAttribute("errorCount", errorCount);
        req.setAttribute("topKeywords", topKeywords);
        req.setAttribute("avgLatency", avgLatency);

        req.getRequestDispatcher("/dashboard.jsp").forward(req, resp);
        System.out.println("DashboardServlet: Loading logs...");

    }
}
