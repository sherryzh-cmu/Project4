/*
Author: Sherry Zhang
Date: 11/21/2025
Project 4
Disclaimer: I used GenAI tools to help me debug my code.
 */
package edu.heinz.project4;

import com.google.gson.annotations.SerializedName;
import java.util.ArrayList;
import java.util.List;

public class BookResponse {

    @SerializedName("numFound")
    public int numFound;

    @SerializedName("docs")
    public List<Doc> docs;

    // Inner class – matches OpenLibrary fields
    public static class Doc {
        @SerializedName("title")
        public String title;

        @SerializedName("author_name")
        public List<String> authorName;

        @SerializedName("first_publish_year")
        public Integer firstPublishYear;
    }

    // Convert OpenLibrary docs → your simplified Book class
    public List<Book> toSimpleList() {
        List<Book> list = new ArrayList<>();
        if (docs == null) return list;

        for (Doc d : docs) {
            String author = (d.authorName != null && !d.authorName.isEmpty())
                    ? d.authorName.get(0)
                    : "Unknown";

            list.add(new Book(
                    d.title != null ? d.title : "Unknown",
                    author,
                    d.firstPublishYear != null ? d.firstPublishYear : -1
            ));
        }
        return list;
    }
}
