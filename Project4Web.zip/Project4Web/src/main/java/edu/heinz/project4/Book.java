/*
Author: Sherry Zhang
Date: 11/21/2025
Project 4
Disclaimer: I used GenAI tools to help me debug my code.
 */
package edu.heinz.project4;

public class Book {
    public String title;
    public String author;
    public int firstPublishYear;

    public Book(String title, String author, int firstPublishYear) {
        this.title = title;
        this.author = author;
        this.firstPublishYear = firstPublishYear;
    }
}
