/*
Author: Sherry Zhang
Date: 11/21/2025
Project 4
Disclaimer: I used GenAI tools to help me debug my code.
 */
package edu.heinz.project4;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

import org.bson.Document;

public class MongoUtil {

    private static MongoClient client;

    private static final String CONNECTION_STRING =
            "mongodb+srv://sherryzh:Zq20010618?@cluster0.qscaoz4.mongodb.net/?retryWrites=true&w=majority";

    private static MongoClient getClient() {
        if (client == null) {
            ConnectionString connString = new ConnectionString(CONNECTION_STRING);

            MongoClientSettings settings = MongoClientSettings.builder()
                    .applyConnectionString(connString)
                    .build();

            client = MongoClients.create(settings);
        }
        return client;
    }

    public static MongoDatabase getDatabase() {
        return getClient().getDatabase("project4db");
    }

    public static MongoCollection<Document> getBookCollection() {
        return getDatabase().getCollection("books");
    }

    public static MongoCollection<Document> getMessageCollection() {
        return getDatabase().getCollection("messages");
    }
    public static MongoCollection<Document> getLogsCollection() {
        return getDatabase().getCollection("logs");
    }


}
