/*
Author: Sherry Zhang
Date: 11/21/2025
Project 4
Disclaimer: I used GenAI tools to help me debug my code.
 */
package edu.heinz.project4;

import java.util.ArrayList;
import java.util.List;

public class BookStorage {

    // web service static list
    private static final List<Book> localBooks = new ArrayList<>();

    // add new book
    public static synchronized void addBook(Book book) {
        localBooks.add(book);
    }

    // get local book
    public static synchronized List<Book> getAllBooks() {
        return new ArrayList<>(localBooks);
    }
}
