/*
Author: Sherry Zhang
Date: 11/21/2025
Project 4
Disclaimer: I used GenAI tools to help me debug my code.
 */
package edu.heinz.project4;

import com.google.gson.Gson;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.bson.Document;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

@WebServlet(name = "MessageServlet", value = "/messages")
public class MessageServlet extends HttpServlet {

    private static final Gson gson = new Gson();
    private static final AtomicLong counter = new AtomicLong(0);
    private static final Random random = new Random();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws IOException, ServletException {

        resp.setContentType("application/json;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        out.println(
                gson.toJson(
                        MongoUtil.getMessageCollection()
                                .find()
                                .into(new java.util.ArrayList<>())
                )
        );
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException, ServletException {

        resp.setContentType("application/json;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        // 1. read POST body
        StringBuilder sb = new StringBuilder();
        BufferedReader br = req.getReader();
        String line;
        while ((line = br.readLine()) != null) {
            sb.append(line);
        }
        br.close();

        // 2. body to JSON map
        Document input = Document.parse(sb.toString());
        String message = input.getString("message");

        // 3. WAL Log Document
        Document log = new Document()
                .append("timestamp", System.currentTimeMillis())
                .append("counter", counter.incrementAndGet())
                .append("randomValue1", random.nextInt(2_000_000))
                .append("randomValue2", random.nextInt(50_000))
                .append("message", message);

        // 4. write in Mongo
        MongoUtil.getMessageCollection().insertOne(log);

        // 5. return OK
        out.println("{\"status\":\"ok\"}");
        out.flush();
    }
}
